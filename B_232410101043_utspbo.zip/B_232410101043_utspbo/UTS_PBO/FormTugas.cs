﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UTS_PBO.Models;
using UTS_PBO.Controllers;

namespace UTS_PBO
{
    public partial class FormTugas : Form
    {
        private tugasControllers _controller;
        public FormTugas()
        {
            InitializeComponent();
            _controller = new tugasControllers();
        }

        


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormTugas_Load_1(object sender, EventArgs e)
        {
            LoadDatatugas();
        }

        private void LoadDatatugas()
        {
            List<tugas> TugasList =
            _controller.GetAlltugas();
            dataGridView1.DataSource = TugasList;
        }
    }
}
