﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UTS_PBO.Models;
using UTS_PBO.Database;
using Npgsql;

namespace UTS_PBO.Controllers
{
    internal class tugasControllers
    {
        public List<tugas> GetAlltugas()
        {
            List<tugas> TugasList = new List<tugas>();
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM tugas";
                using (var cmd = new NpgsqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        TugasList.Add(new tugas
                        {
                            Id = reader.GetInt32(0),
                            judul = reader.GetString(1),
                            deskripsi = reader.GetString(2),
                            deadline = reader.GetString(3),
                        });
                    }
                }
            }
            return TugasList;
        }

        public void Addtugas(tugas tugas1)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "INSERT INTO tugas (judul, deskripsi,deadline) VALUES(@judul, @deskripsi,@deadline)";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("judul", tugas1.judul);
                    cmd.Parameters.AddWithValue("deskripsi", tugas1.deskripsi);
                    cmd.Parameters.AddWithValue("deadline", tugas1.deadline);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
