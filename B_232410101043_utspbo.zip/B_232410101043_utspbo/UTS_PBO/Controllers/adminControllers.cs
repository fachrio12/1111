﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UTS_PBO.Models;
using UTS_PBO.Database;
using Npgsql;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace UTS_PBO.Controllers
{
    internal class adminControllers
    {
        public List<admin> GetAlladmin()
        {
            List<admin> adminList = new List<admin>();
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM admin";
                using (var cmd = new NpgsqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        adminList.Add(new admin
                        {
                            Id = reader.GetInt32(0),
                            username = reader.GetString(1),
                            password = reader.GetString(2),

                        });
                    }
                }
            }
            return adminList;

        }

        public void Addadmin(admin admin1)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "INSERT INTO admin (username, password) VALUES(@username, @password)";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("username", admin1.username);
                    cmd.Parameters.AddWithValue("password", admin1.password);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public admin GetAdminByUSNAndPassword(string username,string password)
        {
            admin admin1 = null;
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT * FROM admin WHERE username = @username AND password = @password";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("username", username);
                    cmd.Parameters.AddWithValue("password", password);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            admin1 = new admin
                            {
                                Id = reader.GetInt32(0),
                                username = reader.GetString(1),
                                password = reader.GetString(2)
                            };
                        }
                    }
                }
            }
            return admin1;
        }
    }

}

