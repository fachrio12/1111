namespace UTS_PBO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                FormTugas formTugas = new FormTugas();
                formTugas.Show();
            }
            else if (checkBox2.Checked)
            {
                FormRegistrasi formRegistrasi = new FormRegistrasi();
                formRegistrasi.Show();
            }
            else if (checkBox3.Checked)
            {
                FormLogin formLogin = new FormLogin();
                formLogin.Show();
            }
            else
            {
                MessageBox.Show("Pilih salah satu");
            }
            this.Hide();
        }
    }
}
