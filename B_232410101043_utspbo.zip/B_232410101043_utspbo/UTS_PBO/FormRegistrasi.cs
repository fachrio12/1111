﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UTS_PBO.Models;
using UTS_PBO.Controllers;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace UTS_PBO
{
    public partial class FormRegistrasi : Form
    {
        private adminControllers _controller;
        public FormRegistrasi()
        {
            InitializeComponent();
            _controller = new adminControllers();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            admin admin1 = new admin
            {
                username = textBox1.Text,
                password = textBox2.Text

            };
            _controller.Addadmin(admin1);
            MessageBox.Show("Registrasi berhasil!");
            FormLogin formLogin = new FormLogin();
            formLogin.Show();
            this.Hide();
        }

        private void FormRegistrasi_Load(object sender, EventArgs e)
        {

        }
    }
}
