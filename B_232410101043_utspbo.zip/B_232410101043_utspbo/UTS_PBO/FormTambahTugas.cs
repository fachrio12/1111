﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UTS_PBO.Models;
using UTS_PBO.Controllers;

namespace UTS_PBO
{
    public partial class FormTambahTugas : Form
    {
        private tugasControllers _controller;
        public FormTambahTugas()
        {
            InitializeComponent();
            _controller = new tugasControllers();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tugas tugas1 = new tugas
            {
                judul = textBox1.Text,
                deskripsi = textBox2.Text,
                deadline = textBox3.Text

            };
            _controller.Addtugas(tugas1);
            MessageBox.Show("Tambah berhasil!");
            FormLogin formLogin = new FormLogin();
            formLogin.Show();
            this.Hide();
        }
    }
}
