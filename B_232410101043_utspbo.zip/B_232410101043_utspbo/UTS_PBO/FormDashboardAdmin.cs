﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UTS_PBO.Models;
using UTS_PBO.Controllers;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace UTS_PBO
{
    public partial class FormDashboardAdmin : Form
    {
        private tugasControllers _controller;
        public FormDashboardAdmin()
        {
            InitializeComponent();
            _controller = new tugasControllers();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void FormDashboardAdmin_Load(object sender, EventArgs e)
        {
            LoadDatatugas();
        }

        private void LoadDatatugas()
        {
            List<tugas> TugasList =
            _controller.GetAlltugas();
            dataGridView1.DataSource = TugasList;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            FormTambahTugas formTambah = new FormTambahTugas();
            formTambah.Show();
            this.Hide();
        }
    }
}
