﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UTS_PBO.Models;
using UTS_PBO.Controllers;

namespace UTS_PBO
{
    public partial class FormLogin : Form
    {
        private adminControllers _controller;
        public FormLogin()
        {
            InitializeComponent();
            _controller = new adminControllers();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username= textBox1.Text;
            string password = textBox2.Text;
            admin admin1 =
            _controller.GetAdminByUSNAndPassword(username, password);
            if (admin1 != null)
            {
                MessageBox.Show("Login berhasil!");
                FormDashboardAdmin formTambah = new FormDashboardAdmin();
                formTambah.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("username atau password salah.");
            }

        }
    }
}
